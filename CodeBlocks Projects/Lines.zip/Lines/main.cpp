
#include <iostream>\
#include <string>
#include <vector>
#include <queue>

using namespace std;

struct Coordinates {
    int x;
    int y;
public:
    Coordinates(int x, int y)
    {
        this -> x = x;
        this -> y = y;
    }
};

Coordinates s_map (vector<vector<char> > in, char target)
{
    for(int i = 0; i < in.size(); ++i)
    {
        for(int j = 0; i < in[i].size(); ++i)
        {
            if (in[i][j] == target)
            {
                Coordinates out = new Coordinates(j, i);
                return out;
            }
        }
    }
}

queue<Coordinates> s_neighbours (vector<vector<char> > in,
                                 vector<vector<bool> > visited,
                                 Coordinates pos)
{
    queue<Coordinates> out;
    if (in[pos.x + 1][pos.y + 1] == '.' && !visited[pos.x + 1][pos.y + 1])
        out.push(Coordinates(pos.x + 1, pos.y + 1));
    if (in[pos.x - 1][pos.y + 1] == '.' && !visited[pos.x - 1][pos.y + 1])
        out.push(Coordinates(pos.x - 1, pos.y + 1));
    if (in[pos.x + 1][pos.y - 1] == '.' && !visited[pos.x + 1][pos.y - 1])
        out.push(Coordinates(pos.x + 1, pos.y - 1));
    if (in[pos.x - 1][pos.y - 1] == '.' && !visited[pos.x - 1][pos.y - 1])
        out.push(Coordinates(pos.x - 1, pos.y - 1));
    return out;
}

Coordinates c_neighbours (vector<vector<char> > in, Coordinates pos)
{
    if (in[pos.x + 1][pos.y + 1] == 'X')
        return Coordinates(pos.x + 1, pos.y + 1);
    if (in[pos.x - 1][pos.y + 1] == 'X')
        return Coordinates(pos.x - 1, pos.y + 1);
    if (in[pos.x + 1][pos.y - 1] == 'X')
        return Coordinates(pos.x + 1, pos.y - 1);
    if (in[pos.x - 1][pos.y - 1] == 'X')
        return Coordinates(pos.x - 1, pos.y - 1);
    return Coordinates(-1, -1)
}


int main()
{
    int size;
    cin >> size;


    // Initaliser of base map
    vector<vector<char> > map_in;
    map_in.resize(size, vector<char>(size, ' '));
    vector<vector<bool> > visited;
    visited.resize(size, vector<bool>(size, false));

    // Input lines to array
    for(int i = 0; i < size; ++i)
    {
        string buffer;
        getline(cin, buffer);
        for(int j = 0; j < size; ++j)
        {
            map_in[i][j] = buffer[j];
        }
    }
/*
    I wasn't able to figure out how to create multiple queue instances for the
    different paths. I have finished the input section, but not the output
    formatting. The code is currently non-functional, and I will resubmit if I
    get it working.
*/

    // Find positions of ball and ending spot
    Coordinates ball = s_map(map_in, '@');

    if (c_neighbours(map_in, ball) != Coordinates(-1, -1))
    {

    }
    // Search through all points, pushing unseen possible paths to a queue
    queue<Coordinates> s_queue;
    s_queue.push(ball);

    while

    return 0;
}
